# -*- coding: UTF-8 -*-
# 1521005 马宏元

def strTool(a):
	intCount = 0  #用来记录列表中的int元素个数
	strCount = 0 #记录str元素个数
	otherCount = 0
	# 使用for循环遍历字符串，每次循环判断当前获取的元素的类型，并给对应计数器计数
	for i in a:   
		if i.isdigit(): #判断i是不是int
			intCount += 1
		elif i.isalpha(): #判断i是不是str
			strCount += 1
		else:
			otherCount += 1
	print ("num=%d,alphabet=%d,other=%d" % (intCount,strCount,otherCount))

def prime(n):
	for i in range(2, n):
		if n % i == 0:
			print(" %d is not a prime number！" % n)
			break
	else:
		print(" %d is a prime number！" % n)